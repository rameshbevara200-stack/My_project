# College Project Hub — deployment guide

This repository has a Vite/React frontend (`client/`) and an Express/TypeScript API (`server/`). Recommended beginner setup: Vercel for the frontend, Render for the API, and MongoDB Atlas for persistent data. The frontend now reads `VITE_API_URL` at build time.

## 1. Push this project to GitHub
1. Create a new GitHub repository.
2. Upload the contents of this folder (the files inside `dt`, not the outer ZIP folder). Do not upload `.env` files or secrets.

## 2. Create a MongoDB Atlas database
1. Create a free cluster at https://www.mongodb.com/atlas.
2. Create a database user and password.
3. In Network Access, allow access from Render. For a simple first deployment, Atlas may require `0.0.0.0/0`; use a strong database password and restrict access when possible.
4. Copy the Atlas connection string and replace the password placeholder. Use database name `college-project-hub`.

## 3. Deploy the API on Render
1. Open https://dashboard.render.com and choose New > Web Service. Connect your GitHub repo.
2. Set **Root Directory** to `server`.
3. Build Command: `npm install && npm run build`
4. Start Command: `npm start`
5. Add these environment variables in Render (use your own secret values):
   - `NODE_ENV` = `production`
   - `MONGODB_URI` = your Atlas connection string
   - `JWT_SECRET` = a long random secret (do not reuse the example/default)
   - `COLLEGE_DOMAIN` = `@rguktsklm.ac.in`
   - `SMTP_HOST` = `smtp.gmail.com` (optional if using Gmail)
   - `SMTP_PORT` = `587` (optional if using Gmail)
   - `SMTP_USER` = your sender Gmail address (optional)
   - `SMTP_PASS` = that account's Google App Password (optional; never use your normal Gmail password)
   - `SMTP_FROM` = a sender label/address you control (optional)
6. Deploy and copy the Render service URL, e.g. `https://your-api.onrender.com`. Check `https://your-api.onrender.com/api/health`.

## 4. Deploy the frontend on Vercel
1. Open https://vercel.com/new and import the same GitHub repository.
2. Set **Root Directory** to `client`. Framework should be Vite.
3. Build Command: `npm run build`; Output Directory: `dist`; Install Command: `npm install`.
4. Add environment variable `VITE_API_URL` = your Render service URL, with no `/api` at the end (for example `https://your-api.onrender.com`).
5. Deploy. The Vercel URL is the public frontend link.

## Important notes
- If you add or change `VITE_API_URL`, redeploy the Vercel frontend because Vite embeds it during the build.
- Free Render web services can sleep when idle, so the first request may be slow.
- Email delivery works only after valid SMTP values are configured.
- The server seeds demo records on startup when the database is empty. Review `server/src/seed.ts` and remove/adjust demo credentials before sharing with real users. Do not use demo accounts for real data.
- Never paste database passwords, SMTP app passwords, or JWT secrets into public GitHub files or chat.
